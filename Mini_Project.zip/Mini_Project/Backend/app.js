const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database');
const path = require('path');
const Datas = require('./models/Authdb');
const cors = require('cors');
const { error, profile } = require('console');
const bcrypt = require('bcrypt');

const app = express();
app.use(cors())
app.use(express.json());
// app.use(bodyParser.urlencoded({extended:false}));


app.post('/register/:firstName/:lastName/:email/:pass/:confirmPass/:phone', (req,res)=>{
    
    console.log(req.params);
    
    const firstName =req.params.firstName;
    const lastName = req.params.lastName;
    const email = req.params.email;
    const pass = req.params.pass;
    const confirmPass = req.params.confirmPass;
    const phone = req.params.phone;
    
    db.query('INSERT INTO registerdetails (firstName, lastName, email, pass, confirmPass, phone) VALUES (?, ? , ? , ? , ? ,?)',
         [firstName, lastName, email, pass, confirmPass, phone]
    );  

    // res.send(path.join(__dirname, "views", "profile.html"));

});


app.get('/profile/:empEmail', (req, res) => {
  console.log("HELLO");
  const empEmail = req.params.empEmail;
  let data = db.query('SELECT * FROM Demo WHERE empEmail = ?', [empEmail], (error, results) => {
    if (error) {
      // Handle the error
      console.error(error);
      return res.status(500).json({ error: 'Database error' });
    }
    console.log("Welcome");
    console.log(results);
    // Handle the results here
    res.send({results})
    
  });


});

app.post("/login", (req, res) => {

  // const username = req.body.username;

  // const password = req.body.password;

 

  const userdetails = req.body;

 

  db.query(

 

    "SELECT * FROM registerDetails where email=?",

    [registerDetails.email],

    (err, result) => {

      if (err) {

        console.log(err);

        res.status(500).send("An error occurred while inserting data.");

      }

      else if (result.length > 0) {

        console.log("Login successfully");

        res.status(200).send("Login successfully");

 

      } else {

        console.log("Invalid credentials");

        res.status(401).send("Invalid credentials");

 

      }

 

    }

  )

})



app.listen(4000,()=>{
    console.log("running");
});

