const db = require('mysql2');

const pool = db.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'node',
    password: 'root12345'
});


// pool.connect((err)=>{

//     if(err){

//         console.log("mysql error");

//     }else{

//         console.log("mysql success");

//     }

// });

module.exports = pool;