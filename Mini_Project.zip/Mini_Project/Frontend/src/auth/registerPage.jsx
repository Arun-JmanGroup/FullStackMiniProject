import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './login.css';
import './register.css';
import axios from 'axios';


export default function Register(){

    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [pass, setPass] = useState('');
    const [confirmPass, setConfirmPass] = useState('');
    const [phone, setPhone] = useState('');

    const handleFirstNameChange = (event) => {
      setFirstName(event.target.value);
    };
    
    const handleLastNameChange = (event) => {
        setLastName(event.target.value);
      };

    const handleEmailChange = (event) => {
      setEmail(event.target.value);
    };

    const handlePasswordChange = (event) => {
        setPass(event.target.value);
    };

    const handleConfirmPassChange = (event) => {
        setConfirmPass(event.target.value);
    };

    const handlePhoneChange = (event) => {
        setPhone(event.target.value);
    };

    async function getData(e){

        if(pass === confirmPass){
            e.preventDefault();
            await  axios.post(`http://localhost:4000/register/${firstName}/${lastName}/${email}/${pass}/${confirmPass}/${phone}`,{
               firstName,
               lastName,
               email,
               pass,
               confirmPass,
               phone
           }).then((d)=>console.log("abc")).catch((err) => console.log(err));
        }
        else{
            alert("Oops! Password and Confirm Password are different.");
        }
       
    } 
      
     
    return(
        <div className='registercontainer'>
            <img src='authLogo.jpg' alt='JMAN Team Effort'></img>
            <div className='registerDetails'>
                <h2>Register Here</h2>
                <form >
                    <label htmlFor='text'>Enter First Name</label>
                    <input type="text" name="firstName" id="firstName" value={firstName} placeholder='Ex: Chris' autoComplete='on' onChange={handleFirstNameChange} required/>
                    <label htmlFor='text'>Enter Last Name</label>
                    <input type="text" name="lastName" id="lastName" value={lastName} placeholder='Ex: Gayle' autoComplete='on' onChange={handleLastNameChange} required />
                    <label htmlFor="email">Enter Email</label>
                    <input type="email" name="userEmail" id="userEmail" value={email} placeholder='random123@gmail.com' pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" autoComplete='on' onChange={handleEmailChange} required />
                    <label htmlFor="password">Create Password</label>
                    <input type="password" name="userPassword" id="userPassword" value={pass} placeholder='somethingYours' pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,16}$" onChange={handlePasswordChange} required />
                    <label htmlFor="password">Confirm Password</label>
                    <input type="password" name="confirmPassword" id="confirmPassword" value={confirmPass} placeholder='somethingYours' pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,16}$" onChange={handleConfirmPassChange} required />
                    <label htmlFor="phone">Enter Phone Number</label>
                    <input type="tel" name="phoneNumber" id="phoneNumber" value={phone} autoComplete='on' placeholder='1234567890' pattern="[0-9]{10}" onChange={handlePhoneChange} required/><br /><br />
                    <button id="registerButton" type="submit" onClick={getData}><Link id='loginNav' to="/">Register</Link></button>
                </form>
            </div>
        </div>
    );
}

 









// const [firstName, setFirstName] = useState("");
// const [lastName, setLastName] = useState("");
// const [email, setEmail] = useState("");
// const [registerDetails, setRegisterDetails] = useState([]);

// const saveRegisterDetails = () => {
//     let Data = localStorage.getItem("Credentials")? JSON.parse(localStorage.getItem("Credentials") || "") : [];
//     let newData = {
//     name: firstName,
//     password: lastName,
//     Email: email,
//   };
//   console.log("Worked");
//   Data.push(newData);
//   localStorage.setItem("credential", JSON.stringify(Data));
//   console.log(Data);
// }