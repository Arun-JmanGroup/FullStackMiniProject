import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import './login.css';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault(); 

    try {
      const response = await axios.post('http://localhost:4000/login', { email, password });

      if (response.status === 200) {
        alert('Success');
        navigate('/profile');
      } else {
        alert('Invalid credentials');
      }
    } catch (error) {
      console.error('Error during login:', error);
      alert('An error occurred during login: ' + error.message);
    }
  };

  return (
    <div className="container">
      <img src="authLogo.jpg" alt="a food image" />
      <div className="loginDetails">
        <h2>Login Here</h2>
        <form onSubmit={handleLogin}>
          <label htmlFor="userEmail">Enter Email</label>
          <input
            type="email"
            id="userEmail"
            name="email"
            value={email}
            placeholder="random123@gmail.com"
            autoComplete="on"
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <label htmlFor="userPassword">Enter Password</label>
          <input
            type="password"
            id="userPassword"
            name="password"
            value={password}
            placeholder="somethingYours"
            autoComplete="on"
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button id="loginButton" type="submit">Login</button>
        </form>
        <p>
          Don't have an account? <Link to="/register" style={{ color: '#19105B', fontWeight: '550' }}>Register</Link>
        </p>
      </div>
    </div>
  );
}

// import axios from "axios";

// import { useState } from "react";

// import { Link, useNavigate } from "react-router-dom";

// import './Login.css'

// import image from './bgimage.png';

 

 

 

 

 

 

 

 

//Typescript interface




