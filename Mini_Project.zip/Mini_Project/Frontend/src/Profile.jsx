import { useEffect, useState } from 'react';
import './Profile.css';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';


export default function Profile(){

    const [empEmail, setEmpEmail] = useState("karthikeyan.re@jmangroup.com"); 
    const[data, setData] = useState([])

    useEffect(() => {
        console.log("sending")
        axios.get(`http://localhost:4000/profile/${empEmail}`)
        .then((d)=>{
            console.log(d.data.results)
            setData(d.data.results)
        }).catch((err)=>{
            console.log(err)
        })
       
    },[])

    const navigate = useNavigate();
    function logout(){
        navigate('/');
    }

    return(
        <>
            {
                data.map((d) => (
                    <div className="main--container">
                <img id="userImage" src={d.url} alt="an image" />
                <h2 id="userName">{d.empName}</h2>
                <p id="userDesignation">{d.empDesgination}</p>

                <span id="spanForEmpId">
                    <label>EMP No.</label>
                    <p id='empIdParagraph'>{d.empId}</p>
                </span>

                <span id="spanForEmailId">
                    <label>Email :</label>
                    <p id='empEmailParagraph'>{d.empEmail}</p>
                </span>

                <span id="spanForDepartment">
                    <label>Department :</label>
                    <p id='empDepartmentParagraph'>{d.empDepartment}</p>
                </span>

                <span id="spanForPhone">
                    <label>Phone :</label>
                    <p id='empPhoneParagraph'>{d.empPhone}</p>
                </span>

                <span id="spanForDOB">
                    <label>Date of Birth :</label>
                    <p id='empDOBParagraph'>{d.empDOB}</p>
                </span>

                <span id="spanForDOJ">
                    <label>Date of Joining :</label>
                    <p id='empDOJParagraph'>{d.empDOJ}</p>
                </span>

                <span id="spanForWorkLocation">
                    <label>Date of Joining :</label>
                    <p id='empWorkLocationParagraph'>{d.empWorkLocation}</p>
                </span>

                <span id="spanForBloodGroup">
                    <label>Date of Joining :</label>
                    <p id='empBloodGroupParagraph'>{d.empBloodGroup}</p>
                </span>

                <i onClick={logout} id="profileLogout" class="fa-solid fa-arrow-right-from-bracket"></i>
                
        </div>
                ))
            }
        </>
    );
}
